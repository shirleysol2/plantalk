import { useEffect, useState } from 'react';
import { BottomNav } from './components/BottomNav';
import { ChatView } from './components/ChatView';
import { PanelTabs } from './components/PanelTabs';
import { PlanNote } from './components/PlanNote';
import { ProfileGate } from './components/ProfileGate';
import { SettingsView } from './components/SettingsView';
import { chatRooms, summaryStyles } from './data';
import { addMessageToRoom, createRoom } from './services/roomActions';
import { loadProfile, loadRooms, saveProfile, saveRooms } from './services/storage';
import type { PanelId, Profile, TabId } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('chat');
  const [activePanel, setActivePanel] = useState<PanelId>('plan');
  const [rooms, setRooms] = useState(() => loadRooms(chatRooms));
  const [activeRoomId, setActiveRoomId] = useState(() => loadRooms(chatRooms)[0].id);
  const [profile, setProfileState] = useState<Profile | null>(() => loadProfile());
  const [summaryStyle, setSummaryStyle] = useState(summaryStyles[0]);

  useEffect(() => {
    saveRooms(rooms);
  }, [rooms]);

  const setProfile = (nextProfile: Profile) => {
    setProfileState(nextProfile);
    saveProfile(nextProfile);
  };

  const toggleTask = (taskId: number) => {
    setRooms((current) =>
      current.map((room) =>
        room.id === activeRoomId
          ? {
              ...room,
              tasks: room.tasks.map((task) => (task.id === taskId ? { ...task, done: !task.done } : task)),
            }
          : room,
      ),
    );
  };

  const activeRoom = rooms.find((room) => room.id === activeRoomId) ?? rooms[0];
  const showSettings = activeTab === 'settings' || (activeTab === 'chat' && activePanel === 'settings');
  const showPlan = activeTab === 'plan' || (activeTab === 'chat' && activePanel === 'plan');

  const handleCreateRoom = (input: { title: string; destination: string; period: string }) => {
    if (!profile) return;
    const room = createRoom({ ...input, nickname: profile.nickname });
    setRooms((current) => [room, ...current]);
    setActiveRoomId(room.id);
    setActiveTab('chat');
  };

  const handleSendMessage = (text: string) => {
    if (!profile) return;
    setRooms((current) =>
      current.map((room) =>
        room.id === activeRoomId ? addMessageToRoom(room, { nickname: profile.nickname, text }) : room,
      ),
    );
  };

  if (!profile) {
    return <ProfileGate onComplete={setProfile} />;
  }

  return (
    <main className="app-shell">
      <div className="sky-sticker cloud-one" />
      <div className="sky-sticker cloud-two" />
      <div className="plane-sticker" />
      <section className={`chat-column ${activeTab === 'chat' ? 'is-active' : ''}`}>
        <ChatView
          activeRoom={activeRoom}
          activeRoomId={activeRoomId}
          profile={profile}
          rooms={rooms}
          onCreateRoom={handleCreateRoom}
          onSendMessage={handleSendMessage}
          onSelectRoom={setActiveRoomId}
        />
      </section>

      <aside className={`side-panel ${activeTab !== 'chat' ? 'is-active' : ''}`}>
        <PanelTabs activePanel={activePanel} onChange={setActivePanel} />
        <div className={showSettings ? 'panel-view' : 'panel-view is-hidden-mobile'}>
          {showSettings && (
            <SettingsView
              members={activeRoom.members}
              summaryStyles={summaryStyles}
              summaryStyle={summaryStyle}
              onSummaryStyleChange={setSummaryStyle}
            />
          )}
        </div>
        <div className={showPlan ? 'panel-view' : 'panel-view is-hidden-mobile'}>
          {showPlan && (
            <PlanNote
              room={activeRoom}
              rooms={rooms}
              activeRoomId={activeRoomId}
              finalPlan={activeRoom.finalPlan}
              scheduleItems={activeRoom.scheduleItems}
              tasks={activeRoom.tasks}
              decisions={activeRoom.decisions}
              budgetItems={activeRoom.budgetItems}
              onSelectRoom={setActiveRoomId}
              onToggleTask={toggleTask}
            />
          )}
        </div>
      </aside>

      <BottomNav activeTab={activeTab} onChange={setActiveTab} />
    </main>
  );
}
